<?php
// Enable detailed error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Set timezone to Philippines
date_default_timezone_set('Asia/Manila');

// Log file for debugging
$log_file = 'rfid_debug.log';
$timestamp = date('Y-m-d H:i:s');

// Log the incoming request
file_put_contents($log_file, "\n\n" . $timestamp . " - New GET Request for Logs\n", FILE_APPEND);

// Log all request headers
foreach (getallheaders() as $name => $value) {
    file_put_contents($log_file, "Header: $name: $value\n", FILE_APPEND);
}

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Database connection settings
$servername = "localhost";
$username = "root"; // Default username for MySQL in XAMPP
$password = ""; // Default password for MySQL in XAMPP
$dbname = "it414_db_shift_happens"; // Your database name

// Create a connection to MySQL database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    $error_msg = "Database connection failed: " . $conn->connect_error;
    file_put_contents($log_file, "DB ERROR: " . $error_msg . "\n", FILE_APPEND);

    http_response_code(500);
    echo json_encode([ "status" => "error", "message" => $error_msg ]);
    exit();
}

file_put_contents($log_file, "Database connected successfully\n", FILE_APPEND);

// Fetch the logs from the database
$sql = "SELECT id, rfid_data, rfid_status, time_log FROM rfid_logs ORDER BY time_log DESC"; // Customize the query as needed
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $logs = [];
    while ($row = $result->fetch_assoc()) {
        $logs[] = $row;
    }
    echo json_encode([ "status" => "success", "data" => $logs ]);
} else {
    echo json_encode([ "status" => "error", "message" => "No logs found" ]);
}

// Close the database connection
$conn->close();
?>
