<?php
header("Access-Control-Allow-Origin: *"); 
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); 
header("Access-Control-Allow-Headers: Content-Type, Authorization");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Asia/Manila');

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "it414_db_shift_happens";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(["status" => "error", "message" => "DB connection failed: " . $conn->connect_error]);
    exit();
}

// GET request: return registered users and logs
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $regResult = $conn->query("SELECT rfid_id, rfid_status FROM rfid_reg ORDER BY rfid_id ASC");
    $logsResult = $conn->query("SELECT rfid_id, rfid_status, time_log FROM rfid_logs ORDER BY time_log DESC LIMIT 50");

    $regData = [];
    while ($row = $regResult->fetch_assoc()) $regData[] = $row;

    $logsData = [];
    while ($row = $logsResult->fetch_assoc()) $logsData[] = $row;

    echo json_encode([
        "status" => "success",
        "reg" => $regData,
        "logs" => $logsData
    ]);
    exit();
}

// POST request: toggle registered RFID, log unregistered as NULL
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $raw_input = file_get_contents('php://input');
    $data = json_decode($raw_input, true);

    if (!$data || !isset($data['rfid_data'])) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Missing rfid_data"]);
        exit();
    }

    $rfid_data = $conn->real_escape_string(trim($data['rfid_data']));
    $time_log = date('Y-m-d H:i:s');

    // Check if RFID exists in registered table
    $check_sql = "SELECT rfid_status FROM rfid_reg WHERE rfid_id = '$rfid_data'";
    $result = $conn->query($check_sql);

    if ($result && $result->num_rows > 0) {
        // Toggle status
        $row = $result->fetch_assoc();
        $new_status = ($row['rfid_status'] == 1) ? 0 : 1;

        // Update rfid_reg
        $update_sql = "UPDATE rfid_reg SET rfid_status = $new_status WHERE rfid_id = '$rfid_data'";
        $conn->query($update_sql);


        echo json_encode([
            "status" => "success",
            "message" => "RFID toggled",
            "rfid_data" => $rfid_data,
            "rfid_status" => $new_status
        ]);

    } else {
        // Unregistered RFID, log as NULL
        $log_sql = "INSERT INTO rfid_logs (time_log, rfid_id, rfid_status) VALUES ('$time_log', '$rfid_data', NULL)";
        $conn->query($log_sql);

        http_response_code(404);
        echo json_encode([
            "status" => "error",
            "message" => "RFID not registered",
            "rfid_data" => $rfid_data
        ]);
    }
}

$conn->close();
?>
